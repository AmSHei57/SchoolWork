LOGOUT: is used to log out of the chatroom

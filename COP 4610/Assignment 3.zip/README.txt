Members:
Amin Sheikhnia, 5771314
Dario Quintanilla, 4851775
Miguel Martinez, 6090425
Carlos Debasa, 3333992

We had been able to do most of each task however, we do not think that the 2nd and 3rd tasks
will work perfectly. Throughout our codes there maybe some bugs
we are unaware of, but we followed the pseudocode and the instructions the 
best we could. Amin and Dario worked on tasks 1, while Miguel and Carlos 
worked on task 2. Everyone worked on task 3. We helped each other to the best of our abilities. 
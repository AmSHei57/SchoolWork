package nachos.threads;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import nachos.machine.*;
import java.util.TreeSet;




public class PriorityScheduler extends Scheduler {



    public PriorityScheduler() {
    }


    public ThreadQueue newThreadQueue(boolean transferPriority) {
      return new PriorityQueue(transferPriority);
    }

    public int getPriorityThread(KThread thread) {
        Lib.assertTrue(Machine.interrupt().disabled());
        return getThreadState(thread).getPriority();
    }

    public int getEffectivePriorityThread(KThread thread) {
        Lib.assertTrue(Machine.interrupt().disabled());
  return getThreadState(thread).getEffectivePriority();
    }

    public void setPriority(KThread thread, int priority) {
     Lib.assertTrue(Machine.interrupt().disabled());
  Lib.assertTrue(priority >= priorityMinimum &&
  priority <= priorityMaximum);
     getThreadState(thread).setPriority(priority);
    }

    public boolean increasePriorityThread() {
     boolean intStatus = Machine.interrupt().disable();
        KThread thread = KThread.currentThread();
     int priority = getPriorityThread(thread);
        if (priority == priorityMaximum)
            return false;
        setPriority(thread, priority+1);
     Machine.interrupt().restore(intStatus);
        return true;
    }

    public boolean decreasePriority() {
        boolean intStatus = Machine.interrupt().disable();
     KThread thread = KThread.currentThread();
     int priority = getPriorityThread(thread);
     if (priority == priorityMinimum)
         return false;
     setPriority(thread, priority-1);
     Machine.interrupt().restore(intStatus);
     return true;
    }


public static final int priorityThreadDefault = 1;



public static final int priorityMinimum = 0;



public static final int priorityMaximum = 7;



protected ThreadState getThreadState(KThread thread) {
    if (thread.schedulingState == null)
        thread.schedulingState = new ThreadState(thread);
    return (ThreadState) thread.schedulingState;
}



protected class PriorityQueue extends ThreadQueue {
 PriorityQueue(boolean transferPriority) {
      this.transferPriority = transferPriority;
  }
 
    public void waitForAccess(KThread thread) {
        Lib.assertTrue(Machine.interrupt().disabled());
        getThreadState(thread).waitForAccess(this);
 }
 
    public void acquire(KThread thread) {
        Lib.assertTrue(Machine.interrupt().disabled());
     getThreadState(thread).acquire(this);
 }
 
    public KThread nextThread() {
     Lib.assertTrue(Machine.interrupt().disabled());
        if (lockHolder != null)
      getThreadState(lockHolder).release(this);
        ThreadState tempThreadState = this.pickNextThread();
     if (tempThreadState == null)
      return null;
     else
      return tempThreadState.thread;
 }



  protected ThreadState pickNextThread() {
        if (waitQueue.isEmpty())
   return null;
  else{
   int c = 0;
   int weight;
   ThreadState nextThreadState = null;
   ThreadState tempThreadState;
   for (Iterator i = waitQueue.iterator(); i.hasNext();){
    tempThreadState = (ThreadState) i.next();
    weight = tempThreadState.goodness(this.transferPriority);
    if (weight > c){
     c = weight;
     nextThreadState = tempThreadState;
    }
   }
        }
        if (c == 0){
            ThreadState tempThreadState1;
   for (Iterator i = waitQueue.iterator(); i.hasNext();){
    tempThreadState1 = (ThreadState) i.next();
    if (this.transferPriority)
     tempThreadState1.setCounter( tempThreadState1.getEffectivePriorityThread());
    else
     tempThreadState1.setCounter( tempThreadState1.getPriorityThread() );
   }
  c = 0;
  nextThreadState = null;
  for(Iterator i = waitQueue.iterator(); i.hasNext();){
   tempThreadState = (ThreadState) i.next();
   weight = tempThreadState.goodness(this.transferPriority);
   if (weight > c){
    c = weight;
    nextThreadState = tempThreadState;
   }
   }
  if (c == 0)
   return null;
  else
   return nextThreadState;
    }
    else
    return nextThreadState;
 }
}

public boolean decreaseCounter(KThread thread)
  {
   return getThreadState(thread).decreaseCounter();
  }
public void print() {
Lib.assertTrue(Machine.interrupt().disabled());
// implement me (if you want)
}

  public boolean transferPriority;
  public LinkedList waitQueue = new LinkedList();
  public KThread lockHolder = null;

protected class ThreadState {


  public ThreadState(KThread thread) {
      this.thread = thread;
      setPriority(priorityThreadDefault);
  }


  public int getPriorityThread() {
      return priority;
  }



 public int getEffectivePriorityThread() {  
   int effectivePriority = this.priority;
   for (Iterator i = myQueue.iterator(); i.hasNext();) {
            PriorityQueue tempQueue = ((PriorityQueue) i.next() );
   if (tempQueue.lockHolder == this.thread){
                for (Iterator j = tempQueue.waitQueue.iterator(); i.hasNext(); ){
     ThreadState tempThreadState = ((ThreadState) i.next() );
     if(tempThreadState.getPriorityThread() > effectivePriority)
                        effectivePriority = tempThreadState.getPriorityThread();
    }
   }
  }
  return effectivePriority;
 }


  public void setPriority(int priority) {
  if (this.priority == priority)
   return;
  this.priority = priority;
  }



  public void waitForAccess(PriorityQueue waitQueue) {
  if (this.counter == -1) {
       if (waitQueue.transferPriority)
        this.counter = this.getEffectivePriorityThread();
    else
     this.counter = this.priority;
  }
        waitQueue.waitQueue.add(this);
  this.myQueue.add((PriorityQueue)waitQueue);
    }



  public void acquire(PriorityQueue waitQueue) {
        Lib.assertTrue(Machine.interrupt().disabled());
  Lib.assertTrue(waitQueue.waitQueue.isEmpty());
  this.myQueue.add((PriorityQueue) waitQueue);
  if(waitQueue.transferPriority)
      waitQueue.lockHolder = this.thread;
  } 
 
  public int goodness(boolean transferPriority) {
   if (this.counter == 0)
    return 0;
   else if (transferPriority)
    return this.counter + this.getEffectivePriorityThread();
   else
    return this.counter + this.priority;
  }
 
  public void release(PriorityQueue waitQueue) {
   this.myQueue.remove(waitQueue);
   waitQueue.lockHolder = null;
  }
 
  public void setCounter(int newCounter) {
        if (newCounter < 0)
            return;
  this.counter = newCounter;
  }
 
  public int getCounter() {
   return this.counter;
  }
 
  public boolean decreaseCounter() {
   if (this.counter == 0)
    return false;
   else {
    this.counter = this.counter - 1;
    if (this.counter == 0)
     return false;
    else
    return true;
   }
  }

  
  protected LinkedList myQueue = new LinkedList();
  protected int priority;
  protected int counter = -1;
 }
}
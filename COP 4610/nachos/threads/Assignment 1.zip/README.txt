Members:
Amin Sheikhnia, 5771314
Dario Quintanilla, 4851775
Miguel Martinez, 6090425
Carlos Debasa, 3333992

We had been able to finish all the tasks however, we do not think that the 5th 
and 3rd tasks will work perfectly. Throughout our codes there maybe some bugs
we are unaware of, but we followed the pseudocode and the instructions the 
best we could. 

Each of us looked at one of the java files on the Nachos API Javadoc and relayed
what each of the files should be doing. Amin and Dario worked on the first 3 tasks
, while Miguel and Carlos worked on the harder last 2 tasks. Though whenever
the others needed help we helped the best we could. 
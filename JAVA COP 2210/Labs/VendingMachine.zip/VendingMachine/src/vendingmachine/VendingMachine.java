/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vendingmachine;

/**
 *
 * @author aminspects
 */
public class VendingMachine {

 private int tokens;
 private int cans;
 
 public VendingMachine(){
     tokens = 0;
     cans = 10;
 }
 public VendingMachine(int numCans){
    tokens = 0; 
   cans = numCans;  
 }
  public void insertToken(){
  
  cans = cans - 1;
  tokens = tokens + 1;  
  }
   
  public void fillUp(int Cans){
  
 cans = Cans;
  }
  
  public int getCanCount(){
      return cans;
  }
  
  public int getTokenCount(){
      return tokens;
  }
    public static void main(String[] args) {
        
        VendingMachine machine = new VendingMachine();
      machine.fillUp(10); // Fill up with ten cans
      machine.insertToken();
      machine.insertToken();
      System.out.print("Token count: ");
      System.out.println(machine.getTokenCount());
      System.out.println("Expected: . . .");
      System.out.print("Can count: ");
      System.out.println(machine.getCanCount()); 
      System.out.println("Expected: . . .");

    }
    
}

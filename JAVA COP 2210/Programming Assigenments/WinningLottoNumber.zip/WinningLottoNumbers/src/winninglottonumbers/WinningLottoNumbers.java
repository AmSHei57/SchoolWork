//********************************************************************************
// PantherID:  5771314
// CLASS: COP 2210 Ã¢â‚¬â€œ 2016
// ASSIGNMENT # 1
// DATE: 9/8/16
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************
package winninglottonumbers;

import java.util.Random;
import javax.swing.JOptionPane;

public class WinningLottoNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    Random r = new Random();  	
int x = 1 + r.nextInt(36);
        
String lotto = JOptionPane.showInputDialog("Would you like to use Fantasy 5 number generator?");
        
JOptionPane.showMessageDialog(null, "Here are your numbers:" + "   " + (1 + r.nextInt(36)) + " " + (1 + r.nextInt(36)) + " " + 
        (1 + r.nextInt(36)) + " " + (1 + r.nextInt(36)) + " " + (1 + r.nextInt(36)) + " " );


        
        
        
        
    } 
    
}

/*=======================================================================
|   Source code:  Craps.Java
|
|              Class: Craps 
|
|           Author:  Amin Sheikhnia
|     Student ID:  5771314
|    Assignment:  Program #3 - Craps
|  
|            Course:  COP 3337 (Intermediate Programming)
|           Section:  U02
|        Instructor:  William Feild  
|        Due Date:  20 February 2018, by the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java
|  Compile/Run: 
| 	javac Analyzer.java Craps.java Die.java
|	java Craps
|
|        Purpose:  The purpose of this class is to play one game of craps using
|                  the Die class.
|
|  Inherits From:  None
|     Interfaces:  None
|
|  +-----------------------------------------------------------------------
|
|      Constants:  NATURAL - the name of 7 in the game Craps
|                  YO_LEVEN - the name of 11 in the game Craps
|                  SNAKE_EYES - the name of 2 in the game Craps  
|                  ACE_DEUCE - the name of 3 in the game Craps  
|                  BOX_CARS - the name of 12 in the game Craps
|                  INCREMENT - used to increment by 1
|                  ORIGINAL - used to set values to 0
|
| +-----------------------------------------------------------------------
|
|   Constructors:  None
|
|  Class Methods:  None
|
|  Instance Methods:  public void playGame();
|                     public void resetGame();
|                     public int getroll();
|                     public boolean gedDecision();
|                     public boolean getComingOutWin();
|                     public boolean getContinuationComingOutRoll();
|*===========================================================================*/ 

/*---------------------------- playGame ----------------------------------------
        |  Method playGame() 
        |
        |  Purpose:  To use the Die class to simulate a game of Craps
        |
        |  @param   None
        |
        |  @return  void - None
        *---------------------------------------------------------------------*/
/*---------------------------- resetGame ---------------------------------------
        |  Method resetGame() 
        |
        |  Purpose:  Used to reset all values used in the playGame method
        |
        |  @param   None
        |
        |  @return  void - None
        *---------------------------------------------------------------------*/
/*---------------------------- getRoll -----------------------------------------
        |  Method getRoll() 
        |
        |  Purpose:  Used to return number of rolls
        |
        |  @param   None
        |
        |  @return  roll - number of rolls
        *---------------------------------------------------------------------*/
/*---------------------------- getDecision -------------------------------------
        |  Method getDecision() 
        |
        |  Purpose:  Used to return if game was won or lost
        |
        |  @param   None
        |
        |  @return  winOrLose - win or lose a game
        *---------------------------------------------------------------------*/
/*---------------------------- getComingOutWin ---------------------------------
        |  Method getComingOutWin() 
        |
        |  Purpose:  Used to return if game was won during the coming out
        |
        |  @param   None
        |
        |  @return  comingOutWin - win during coming out
        *---------------------------------------------------------------------*/
/*---------------------------- getContinuationComingOutRoll --------------------
        |  Method getContinuationComingOutRoll() 
        |
        |  Purpose:  Used to return if game continued after coming out roll
        |
        |  @param   None
        |
        |  @return  continuationComingOutRoll - contiue after coming out roll
        *---------------------------------------------------------------------*/
/*package analyzer;*/

public class Craps {
    
    private int dice1 = 0;
    private int dice2 = 0;
    private int diceA = 0;
    private int diceB = 0;
    private int roll = 0;
    private int value = 0;
    private int point = 0;
    private int comingOut = 0;
    private boolean comingOutBoolean = false;
    private boolean winOrLose = true;
    private boolean continuationComingOutRoll = false;
    
    private final int NATURAL = 7;
    private final int YO_LEVEN = 11;
    private final int SNAKE_EYES = 2;
    private final int ACE_DEUCE = 3;
    private final int BOX_CARS = 12;
    private final int ORIGINAL = 0;
    
    Die dice = new Die(6);
    
    public void playGame()
    {
        dice1 = dice.rollDie();
        dice2 = dice.rollDie();
        roll ++;
        comingOut = dice1 + dice2;
        point = comingOut;
        
        if(comingOut == NATURAL || comingOut == YO_LEVEN)
        {
            winOrLose = true;
            comingOutBoolean = true;
        }
        else if(comingOut != SNAKE_EYES && comingOut != ACE_DEUCE && 
                comingOut != BOX_CARS)
        {
            continuationComingOutRoll = true;
            do
            {
                diceA = dice.rollDie();
                diceB = dice.rollDie();
                roll ++;
                value = diceA + diceB;
                
            }while(value != point && value != NATURAL);
        
            if(value == point)
            {
                winOrLose = true;            
            }
            else
            {
                winOrLose = false;            
            }
        }
        else
        {
            winOrLose = false;        
        }
       
    }//end playGame
    
    public void resetGame()
    {
        dice1 = ORIGINAL;
        dice2 = ORIGINAL;
        diceA = ORIGINAL;
        diceB = ORIGINAL;
        roll = ORIGINAL;
        value = ORIGINAL;
        point = ORIGINAL;
        comingOut = ORIGINAL;
        winOrLose = true;
        comingOutBoolean = false;
        continuationComingOutRoll = false;
    }//end resetGame

    public int getRoll()
    {
        return roll;
    }//end getRoll
    
    public boolean getDecision()
    {
        return winOrLose;   
    }//end getDecision
    
    public boolean getComingOut()
    {
        return comingOutBoolean;
    }//end getComingOut
    
    public boolean getContinuationComingOutRoll()
    {
        return continuationComingOutRoll;
    }//end getContinuationComingOutRoll
            
}//end class
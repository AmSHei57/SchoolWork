/*=============================================================================  
|   Source code:  Analyzer.java
|           Author:  Amin Sheikhnia 
|     Student ID:  5771314 
|    Assignment:  Program #3 - Craps
|  
|           Course:  COP 3337 (Intermediate Programming)
|           Section:  U02
|        Instructor:  William Feild  
|        Due Date:  20 February 2018, by the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java 
|  Compile/Run:  
| 	javac Analyzer.java Craps.java Die.java
|	java Analyzer
| 
|  +----------------------------------------------------------------------------  
|  
|  Description:  This program's job is to create a number of craps games 
|                determined by user input and to use the Craps and Die classes
|                as the means of doing this.This class will record the results
|                of each game and will output the combined information of all
|                the games.
|                  
|        Input:  The user is required to input how many games of craps they 
|                want to play.
|  
|       Output:  The output will include the total number of games played, the 
|                total number of rolls for all games played, average length
|    `           (in rolls) of the games played(total rolls/total games), 
|                longest game played(in rolls),total number of games won,
|                expected probability of winning overall,outcome of winning 
|                overall(total wins/total games),total number of wins 
|                that occured on the coming out roll,total number of 
|                games that ended on the opening(coming out) roll,
|                expected probability of winning on the 
|                opening roll, outcome of winning on the coming out roll(coming
|                out wins/coming out games),expected probalility of the games
|                ending on the coming out roll, outcome of games ending on the
|                coming out roll(coming out games/total games),total number of 
|                games continuing after the coming out roll(wins & loses), 
|                expected probablility of the games continuing after the coming 
|                out roll,outcome of games continuing after the coming out roll 
|                ((total games - coming out games)/total games),summary tally of
|                the number of rolls for each game to finish(1 to 21+).
|  
|     Process:  Facilitate user input on how many games they will play, 
|                calculate the outputs, print out the outputs.
|  
|   Required Features Not Included:  
|                Output 17 was not included
|  
|   Known Bugs:  No known bugs
|  *==========================================================================*/

/*---------------------------- userInputPlayGame -------------------------------
        |  Method userInputPlayGame() 
        |
        |  Purpose:  Used to take in user input and applies this info to craps 
        |            game
        |
        |  @param   None
        |
        |  @return  void - None
        *---------------------------------------------------------------------*/
/*---------------------------- calculations ------------------------------------
        |  Method calculations() 
        |
        |  Purpose:  Used to calculate essential information needed for output
        |
        |  @param   None
        |
        |  @return  void - None
        *---------------------------------------------------------------------*/
/*---------------------------- outputs -----------------------------------------
        |  Method outputs() 
        |
        |  Purpose:  Used to take in user input and applies this info to craps 
        |            game
        |
        |  @param   None
        |
        |  @return  void - None
        *---------------------------------------------------------------------*/
/*---------------------------- main ----------------------------
        |  Method main(args)
        |
        |  Purpose:  Executes the tester program.
        |
        |  @param  args - command-line input not used
        |
        |  @return  void - none
        *-------------------------------------------------------------------*/
/*package analyzer;*/

/*for four decimal place formating*/
import java.text.DecimalFormat;
/*for java I/O*/
import java.util.Scanner;

public class Analyzer 
{
    /*
    http://www.herkimershideaway.org/writings/craps.htm        and
    https://www.wyzant.com/resources/answers/15987/what_is_the_probability_
    of_rolling_a_7_or_11_when_rolling_a_pair_of_dice 
    is where i found:
    EXPECTED_PROBABILITY_WINNING
    EXPECTED_PROBABILITY_OPENING_ROLL
    EXPECTED_PROBABILITY_ENDING_COMING_OUT_ROLL 
    EXPECTED_PROBABILITY_CONTINUING_COMING_OUT_ROLL
    */
   
    private static int totalNumGames = 0;
    private static int totalRolls = 0;
    private static double averageLength = 0.0;
    private static int longestGame = 0;
    private static int totalGamesWon = 0;
    private static double outcomeOfWinningOverall = 0.0;
    private static int comingOutWin = 0;
    private static int comingOutGames = 0;
    private static double outcomeOfWinningComingOutRoll = 0.0;
    private static double outcomeOfGamesEndingComingOutRoll = 0.0;
    private static int continuationComingOutRoll= 0;
    private static double outcomeContinuingComingOutRoll = 0.0;
    
    private final static int ZERO = 0;
    private final static double EXPECTED_PROBABILITY_WINNING = 0.4929;
    private final static double EXPECTED_PROBABILITY_OPENING_ROLL = 0.2222;
    private final static double EXPECTED_PROBABILITY_COMING_OUT_ROLL = 0.2852;
    private final static double EXPECTED_PROBABILITY_CONTINUING_COMING_OUT_ROLL 
                                                                       = 0.2226;
     
    public static void userInputPlayGame()
    {
        Scanner scan = new Scanner(System.in);
        Craps game = new Craps();
        
        int numGames = ZERO;
        int rolls = ZERO;
        
        System.out.println("How many games do you wanna play?");
        numGames = scan.nextInt();
        totalNumGames = numGames;
        
        do
        {
            game.resetGame();
            game.playGame();
            
            calculations();
            
            rolls = game.getRoll();
            
            totalRolls = totalRolls + rolls;
            
            if(game.getDecision() == true)
            {
                totalGamesWon ++;
            }
            if(longestGame < rolls)
            {
                longestGame = rolls;
            }
            if(game.getComingOut() == true)
            {
                comingOutWin ++;
            }
            if(game.getComingOut() == false)
            {
                comingOutGames ++;
            }
            if(game.getContinuationComingOutRoll() == true)
            {
                continuationComingOutRoll ++;
            }
           
            numGames --;
        }
        while(numGames != ZERO);   
    }//end userInputPlayGame
    
    private static void calculations()
    {
        averageLength = (double)totalRolls / (double)totalNumGames;
        
        outcomeOfWinningOverall = (double)totalGamesWon / (double)totalNumGames;
        
        outcomeOfWinningComingOutRoll = (double)comingOutWin / 
                                                         (double)comingOutGames;
        
        outcomeOfGamesEndingComingOutRoll = (double)comingOutGames / 
                                                          (double)totalNumGames;
        
        outcomeContinuingComingOutRoll = ((double)totalNumGames - 
                                (double)comingOutGames) / (double)totalNumGames;
    }//end calculations
    
    public static void outputs()
    {
        DecimalFormat fourDecimal = new DecimalFormat("0.0000");
        System.out.println("The total number of games is " + totalNumGames);
        
        System.out.println("The total number of rolls for all games played is "
                       + totalRolls);
        
        System.out.println("The average length of the games played is " 
                       + fourDecimal.format(averageLength));
        
        System.out.println("The longest game played in rolls is "+ longestGame);
        
        System.out.println("The total number of games won is "+ totalGamesWon);
        
        System.out.println("The expected probability of winning overall is " + 
                           EXPECTED_PROBABILITY_WINNING);
        
        System.out.println("The outcome of winning overall is " + 
                            fourDecimal.format(outcomeOfWinningOverall));
        
        System.out.println("The total number of wins that occured on the "
                       + "coming out roll is "+ comingOutWin);
        
        System.out.println("The total number of games that ended on the coming "
                       + "out roll "+ comingOutGames);
        
        System.out.println("The expected probablility of winning on the "
                       + "opening roll is "+ EXPECTED_PROBABILITY_OPENING_ROLL);
        
        System.out.println("The outcome of winning on the coming out roll is " 
                       + fourDecimal.format(outcomeOfWinningComingOutRoll));
        
        System.out.println("The expected probability of the games ending on "
             + "the coming out roll is "+ EXPECTED_PROBABILITY_COMING_OUT_ROLL);
        
        System.out.println("The outcome of games ending on the coming out roll " 
                       + fourDecimal.format(outcomeOfGamesEndingComingOutRoll));
        
        System.out.println("The total number of games continuing after the "
                       + "coming out roll is " + continuationComingOutRoll);
        
        System.out.println("The expected probability of the games continuing "
             + "after the coming out roll " + 
                               EXPECTED_PROBABILITY_CONTINUING_COMING_OUT_ROLL);
        
        System.out.println("The outcome of games continuing after the coming "
         + "out roll is " + fourDecimal.format(outcomeContinuingComingOutRoll));    
    }//end outputs
    
    public static void main(String[] args) 
    {
        userInputPlayGame();  
        outputs();
    }//end main
}//end class
 
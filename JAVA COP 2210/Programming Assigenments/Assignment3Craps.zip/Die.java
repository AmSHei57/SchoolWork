/*=======================================================================
|   Source code:  Die.Java
|
|              Class: Die 
|
|           Author:  Amin Sheikhnia
|     Student ID:  5771314
|    Assignment:  Program #3 - Craps
|  
|            Course:  COP 3337 (Intermediate Programming)
|           Section:  U02
|        Instructor:  William Feild  
|        Due Date:  20 February 2018, by the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java
|  Compile/Run: 
| 	javac Analyzer.java Craps.java Die.java
|	java Die
|
|        Purpose:  The purpose of this class is to create a die to use in the 
|                  Craps class in order to facilitate a game of Craps.
|
|  Inherits From:  None
|     Interfaces:  None
|
|  +-----------------------------------------------------------------------
|
|      Constants:  LOWER_LIMIT - least amount of sides a die can have
|                  UPPER_LIMIT - max amount of sides a die can have
|                  ELSE_LIMIT - else number of sides if not LOWER_LIMIT and
|                               UPPER_LIMIT
|
| +-----------------------------------------------------------------------
|
|   Constructors:  Die(int);
|
|  Class Methods:  none
|
|  Instance Methods:  public int rollDie();
|
|  *==========================================================================*/ 

/*---------------------------- Die ---------------------------------------------
        |  Method Die(numSides) - Constructor
        |
        |  Purpose:  Constructs a die with number of sides determined by object.
        |
        |  @param   numSides - number of sides 
        |
        |  @return  None
        *---------------------------------------------------------------------*/
/*---------------------------- rollDie -----------------------------------------
        |  Method rollDie() 
        |
        |  Purpose:  Constructs a die with number of sides determined by object.
        |
        |  @param   None
        |
        |  @return  randomNum - a random number
        *---------------------------------------------------------------------*/
/*package analyzer;*/

/* Used to create randomness */
import java.util.Random;

public class Die 
{
    private int sides = 0;
    
    private final int LOWER_LIMIT = 3;
    private final int UPPER_LIMIT = 100;
    private final int ELSE_LIMIT = 6;
    private final int ITERATION = 1;
    
    public Die(int numSides)
    {
        sides = numSides;
        
        if(numSides < LOWER_LIMIT)
        {
            sides = LOWER_LIMIT;
        }
        else if(numSides > UPPER_LIMIT)
        {
            sides = UPPER_LIMIT;   
        }
        else if(numSides!= LOWER_LIMIT || numSides != UPPER_LIMIT )
        {
            sides = ELSE_LIMIT;
        }  
    }//end Die
    
    public int rollDie()
    {  
        
        Random generator = new Random();
        
        int randomNum = ITERATION + generator.nextInt(sides);    
                
        return randomNum;
    }//end  rollDie       
    
    
    
}//end class

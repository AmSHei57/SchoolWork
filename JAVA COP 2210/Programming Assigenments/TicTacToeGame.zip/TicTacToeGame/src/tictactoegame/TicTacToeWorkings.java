/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoegame;

import javax.swing.JOptionPane;

/**
 *The TicTacToeWorkings class is used to initiate the board,
 * to start the game, and to determines when the game will end.
 * @author 5771314 
 */
public class TicTacToeWorkings {

public int row;//The location of the 2D Array in the row category
public int column;//The location of the 2D Array in the column category 
public char[][]board= new char[3][3];//Creates the 2D Array
public char turn = 'X';//Used to determine whose turn it is between X and O  

/**
 * The PrintBoard method is used to print the board
 * so that the user can see the TicTacToe board so that they can
 * determine where would they like to place their token.
 */
    public void PrintBoard(){
for(int i= 0;i<3;i++){
 System.out.println(); 
 for(int j= 0;j<3;j++){
     if(j==0){
     System.out.print("| ");
     }
     System.out.print(board[i][j]+" | ");    
  }    
}   
System.out.println(); 
}
/**
 * The gameIsOver method is used to determine the win conditions to 
 * end or keep the game going.
 */
public boolean WinCondition(int Row, int Column){

if(board[0][Column]==board[1][Column] && board[0][Column]==board[2][Column])
return true;
if(board[Row][0]==board[Row][1] && board[Row][0]==board[Row][2])
return true;
if(board[0][0]==board[1][1] && board[0][0]==board[2][2] && board[1][1]!= '_')
return true;
if(board[0][2]==board[1][1] && board[0][2]==board[2][0] && board[1][1]!= '_')
return true;

return false;
}
/**
 * The Play method is used to initiate the game,
 * to ask the user to input the row number and 
 * column number to place their marker onto the board,and 
 * to refresh the board with either X or O in the desired
 * location they had previously indicated.
 */
public void StartGame(){
    for(int i= 0;i<3;i++){
  for(int j= 0;j<3;j++){
     board[i][j]='_';
  }  
}
boolean play= true;
PrintBoard();
while(play==true){
   String rowInt = JOptionPane.showInputDialog(" Enter a row number starting from 0 to 2. *Warning* Do not place in a occupied spot");
   int rowint = Integer.parseInt(rowInt);
   row = rowint;
   String columnInt = JOptionPane.showInputDialog("Enter a column number statring from 0 to 2. *Warning* Do not place in a occupied spot");
   int columnint = Integer.parseInt(columnInt);
   column=columnint;
   board[row][column]=turn;
   
   if(WinCondition(row,column)){
       play = false;
       JOptionPane.showMessageDialog(null,"Game Over, Player "+ turn + " wins the game");
   }
   PrintBoard();
   if(turn=='X'){
       turn='O';
   }else{
       turn='X';
       
   }


    
}
}   
}

//********************************************************************************
// STUDENT NAME:  5771314
// FIU EMAIL: ashei012@fiu.edu
// CLASS: COP 2210 – 2016
// ASSIGNMENT # 5
// DATE: 11/29/16
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else, except as outlined in the 
// assignment instructions.
//********************************************************************************
package tictactoegame;

import javax.swing.JOptionPane;
import java.util.Random;
/**
 * The TicTacToeGame class is used to initiate the Play method
 * from the TicTacToeWorkings class, as the user for their name,
 * to determine who goes first, and to determine if the user would 
 * like to play again.
 * @author 5771314
 */
public class TicTacToeGame {

    public static void main(String[] args) {
 TicTacToeWorkings TTTW = new TicTacToeWorkings();
        String name = JOptionPane.showInputDialog("Welcome to TicTacToe, what is your name?");

        Random r = new Random();
        
        int decision=1+ r.nextInt(2);//Used to determine who will start
        if(decision==1){
            JOptionPane.showMessageDialog(null,name +" , you will be going first and you're X");
                  }else{
            JOptionPane.showMessageDialog(null,"The computer will go first, they are O");
                       }

TTTW.StartGame();

boolean gameOver=true;//Used to determine if the user wants to play again
while(gameOver==true){
String playAgain = JOptionPane.showInputDialog("Do you want to play again? \"Yes\" or \"No\"");
if(playAgain.equals("Yes")){
    TTTW.StartGame();
    gameOver=true;
}else{
    JOptionPane.showMessageDialog(null,"Thanks For Playing");
    gameOver=false;
}   
    }
    
 }
    
}

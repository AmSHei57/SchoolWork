/*=============================================================================  
|   Source code:  ComputePI
|           Author:  Amin Sheikhnia 
|     Student ID:  5771314  
|    Assignment:  Program #1 ComputePI
|  
|            Course:  COP 3337 (Intermediate Programming)
|           Section:  U02
|        Instructor:  William Feild  
|        Due Date:  25 January 2018, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java 
|  Compile/Run:  [How to Compile and Execute this program, IN DETAIL.] 
| 	javac ComputePI.java  ComputePI.java
|	java ComputePI
| 
|  +----------------------------------------------------------------------------  
|  
|  Description:  A class used to compute PI.
|                  
|        Input:  No input from user needed
|  
|       Output:  The program will output the expected value of PI, the computed
|               of Pi, and the number of iterations needed for six-decimal-place
|                accuracy.
|  
|     Process:  1)I initialized all the variables used before the do while loop.
|               2)I used applied the given formula connected to a variable.
|               3)I then incremented the formula so that it keeps going as the 
|                 do while loop runs its course.
|               4)I created a variable to make it so that there is a 
|                 six-decimal-place accuracy. This variable is also used to 
|                 determine when the do while loop ends.
|               5)I then printed the statements as the output.
|
|   Required Features Not Included:  
|                All features are available in the program.  
|  
|   Known Bugs:  There is a bug that if I use float instead of double the  
|                program would not compile.  
|  *==========================================================================*/

package computepi;


public class ComputePI {

    
    public static void main(String[] args) {
    
     /*initialized variables including 2 constants */
     int numIterations = 0;
     final double EXPECTED_VALUE_DIVIDED_BY_FOUR =  0.78539825;
     final double EXPECTED_VALUE = 3.141593;
     double computedValue = 0;
     double firstTerm = 1;
     double secondTerm = 3;
     double deltaValue = 0;
     
     /*loop that used the PI formula given without multiplying by 4 */
     do
     {
     computedValue = computedValue + (1.0 / firstTerm ) - (1.0 / secondTerm) ;
     
     /*iterated terms*/
     firstTerm = secondTerm + 2;
     secondTerm = firstTerm + 2;
     numIterations++;
     
     /*determines loop end*/
     deltaValue = (computedValue - EXPECTED_VALUE_DIVIDED_BY_FOUR );
     
     /*tests to not allow deltaValue to become negative */
        if(deltaValue < 0)
        {
            deltaValue = (deltaValue * -1.0);
        }
    
     }
     
     /*determines six decimal point accuracy */
     while(deltaValue > 0.0000001);
     
     /*used to find true computedValue due to not multiplying by four in loop*/
     computedValue = computedValue * 4;
     
     /*prints outputs*/
      System.out.println("The expected value for PI is: " + EXPECTED_VALUE);
      System.out.println("The computed value for PI is: " + computedValue);
      System.out.println
        ("The number of iterations needed to compute PI is: " + numIterations);
      
                                           }
                       }

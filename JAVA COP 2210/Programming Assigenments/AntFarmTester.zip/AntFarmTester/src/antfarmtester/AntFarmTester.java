//********************************************************************************
// PantherID:  5771314
// CLASS: COP 2210 2016
// ASSIGNMENT # 2
// DATE: 10/5/16
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//********************************************************************************
package antfarmtester;

import java.util.Random;
import javax.swing.JOptionPane;

class AntFarm{
    
String queenName;
String colonyName;
String caretakerName;
int startingSize;
int feedDays;
int numDied;

public AntFarm(String qName,String cName,String ctName,int sSize){
    queenName = qName;
    colonyName = cName;
    caretakerName = ctName;
    startingSize = sSize;
    feedDays = 0; 
    numDied = 0;
}
private void feed(int n)
{
    feedDays = feedDays + n;
}
public void breed(int n){
startingSize = startingSize * 3;
feed(n);
if(feedDays> 10)
{
    numDied = startingSize * 1/2;
    startingSize = startingSize - numDied;
    JOptionPane.showMessageDialog(null,"The queen died and the number of ants died that died is "+numDied);
}
}

public int getSize()
{
return startingSize;
}
public String getQueenName()
{
return queenName;
} 
}
public class AntFarmTester {

 
    public static void main(String[] args) {
String queen = JOptionPane.showInputDialog("What is the Queen's Name?");
String colony = JOptionPane.showInputDialog("What is the Colony's Name?");
String caretaker = JOptionPane.showInputDialog("What is the Caretaker's Name?");
String starting = JOptionPane.showInputDialog("What is the Starting size is?");
String feed = JOptionPane.showInputDialog("How many days do you want to feed?");
String breed = JOptionPane.showInputDialog("Do you want the Queen to breed? <1(yes) or 2(no)>" );

int s = Integer.parseInt(starting); 
int f = Integer.parseInt(feed);
int b = Integer.parseInt(breed);

JOptionPane.showMessageDialog(null,"The Queen's name is " + queen);
JOptionPane.showMessageDialog(null,"The Colony's name is " + colony);
JOptionPane.showMessageDialog(null,"The Caretaker's name is " + caretaker);
JOptionPane.showMessageDialog(null,"The Starting size is " + s);  
JOptionPane.showMessageDialog(null,"The colony was fed for " + f + " days");

if(b==1){
    JOptionPane.showMessageDialog(null,"The Queen was requested to breed ");
}else{
    JOptionPane.showMessageDialog(null,"The Queen was not requested to breed ");
}

AntFarm antFarm = new AntFarm(queen,colony,caretaker,s);
if(b==1){
antFarm.breed(f);
}

Random r = new Random();

int yesExpand = 1 + r.nextInt(2);
int noExpand = 1 + r.nextInt(10);

String expand = JOptionPane.showInputDialog("Do you want to expand the colony? <1 or 2> ");
int e = Integer.parseInt(expand);
  
if(e == 1)
{
JOptionPane.showMessageDialog(null,"The colony has expanded successfully");
    if(yesExpand==1){
    JOptionPane.showMessageDialog(null,"The new Queen's name is "+antFarm.getQueenName()+"2.0");
    }else{
    JOptionPane.showMessageDialog(null,"And there is no new Queen");
    }
}else{
JOptionPane.showMessageDialog(null,"The colony has not expanded");   
    if(noExpand==1){
    JOptionPane.showMessageDialog(null,"The new Queen's name is "+antFarm.getQueenName()+"2.0");
    }else{
    JOptionPane.showMessageDialog(null,"And there is no new Queen");
    }
}

JOptionPane.showMessageDialog(null,"Final number of ants in the colony: "+antFarm.getSize());

    }
    
}


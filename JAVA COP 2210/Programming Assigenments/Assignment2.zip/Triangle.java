/*=======================================================================
|   Source code:  Triangle.java
|
|              Class: Triangle 
|
|           Author:  Amin Sheikhnia
|     Student ID:  5771314
|    Assignment:  Program #2 - Triangle
|  
|            Course:  COP 3337 (Intermediate Programming)
|           Section:  U02
|        Instructor:  William Feild  
|        Due Date:   2/6/18, at the beginning of class 
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java
|  Compile/Run: 
| 	javac TriangleTester.java Triangle.Java
|	java TriangleTester
|
|        Purpose:  The purpose of this class is to create a triangle in order 
|                  for the tester class to use this triangle to output its
|                  characteristics.                  
|
|  Inherits From:  None
|
|  Interfaces:  None
|  +-----------------------------------------------------------------------
|
|      Constants:  No constants
|
| +-----------------------------------------------------------------------
|
|   Constructors:  setPointLocation(); Constructs x and y coordinates at 0,0 for
|                                      point objetcs
| Class Methods:  None
|
|   Instance Methods:  getPointLocation(); Gets the location of each point via
|                                           x and y coordinates
|
|  *==========================================================================*/ 

/*package triangletester;*/


import java.awt.Point;

/**
 *
 * @author Owner
 */
public class Triangle {
     
    Point firstPoint = new Point();
    Point secondPoint = new Point();
    Point thirdPoint = new Point();
    
    private double firstX = 0.0;
    private double firstY = 0.0;
    private double secondX = 0.0;
    private double secondY = 0.0;
    private double thirdX = 0.0;
    private double thirdY = 0.0;
    
    public void setPointLocation(double x1, double y1, double x2, double y2,
                                 double x3, double y3){
    
    firstX = x1;
    firstY = y1;
    secondX = x2;
    secondY = y2;
    thirdX = x3;
    thirdY = y3;
    
    firstPoint.setLocation(firstX , firstY);
    secondPoint.setLocation(secondX, secondY);
    thirdPoint.setLocation(thirdX, thirdY);
    
    
                                                       }//end setPointLocation

public void getPointLocation(){
    System.out.println("The first point is: " + firstPoint.getX() + " ," +
            firstPoint.getY());
    System.out.println("The second point is: " + secondPoint.getX() + " ," +
            secondPoint.getY());
    System.out.println("The third point is: " + thirdPoint.getX() +  " ," +
            thirdPoint.getY());
                               }//end getPointLocation()


                        }//end class

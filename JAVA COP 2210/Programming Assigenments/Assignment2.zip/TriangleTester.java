/*=============================================================================  
|   Source code:  TriangleTester
|           Author:  Amin Sheikhnia
|     Student ID:  5771314  
|    Assignment:  Program #2 Triangle
|  
|            Course:  COP 3337 Programming II  
|           Section:  U02  
|        Instructor:  William Feild  
|        Due Date:  2/6/18, at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java
|  Compile/Run:   javac TriangleTester.java  Triangle.java
|                 java TriangleTester.java
| 
|  +----------------------------------------------------------------------------  
|  
|  Description:  This program's job is to create and describe a triangle from 
|                user input. The user is asked for 6 coordinate points 
|                that coorelate to each x and y of each point. This is done 
|                through the point class. Then each aspect of the triangle is 
|                 calculated and printed.
|
|        Input:  The user is required to enter 6 x and y coordinates in the form
|                of a double if they so choose. It is expected that the user 
|                knows what coordinates to input.
|  
|       Output:  The program will output the length of all three sides, the
|                three angles, the perimeter, the area, and whether the triangle
|                is Equilateral or Right-angled. All outputs will have four 
|                decimal-point accuracy except the degrees of the angles in 
|                which it will be to the closest degree.
|  
|     Process:  The programs's steps are as follows:
|                1) The program asks for user input
|                2) The information given by the user is calculated 
|                3) The information about the triangle is displayed to user
|  
|   Required Features Not Included:  All features have been included  
|  
|   Known Bugs:  May not determine if the triangle is equilateral or 
|                right-angled. Due to the point class each x and y
|                coordinate is stored as double but is rounded up to the nearest 
|                whole value. Angles do not round to the nearest degree on some
|                occasions.
|  *==========================================================================*/


/*package triangletester;*/


import java.util.Scanner;

public class TriangleTester {
     
     private double x1 = 0.0;
     private double y1 = 0.0;
     private double x2 = 0.0;
     private double y2 = 0.0;
     private double x3 = 0.0;
     private double y3 = 0.0;
    
    /*The prevention of input error was created by Terry Chern,I only modified 
     it in order to suit the needs of the code*/ 
     public void AskValues(){
     
     boolean valid = false;
     
     Scanner scan = new Scanner(System.in);
     Triangle Points = new Triangle();
     
      do{
        System.out.println("Please enter X1 Coordinate: ");
        if(scan.hasNextDouble()){
             x1 = scan.nextDouble();
             valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
      do{
         valid = false;
        System.out.println("Please enter Y1 Coordinate: ");
        if(scan.hasNextDouble()){
             y1 = scan.nextDouble();
            valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
      do{
         valid = false;
        System.out.println("Please enter X2 Coordinate: ");
        if(scan.hasNextDouble()){
             x2 = scan.nextDouble();
            valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
      do{
          valid = false;
        System.out.println("Please enter Y2 Coordinate: ");
        if(scan.hasNextDouble()){
             y2 = scan.nextDouble();
            valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
      do{
          valid = false;
        System.out.println("Please enter X3 Coordinate: ");
        if(scan.hasNextDouble()){
             x3 = scan.nextDouble();
            valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
      do{
          valid = false;
        System.out.println("Please enter Y3 Coordinate: ");
        if(scan.hasNextDouble()){
             y3 = scan.nextDouble();
            valid = true;
                                }
        else{
            System.out.print("Not a valid input!\n");
            scan.next();
            }
         }while(valid == false);
      
     Points.setPointLocation(x1,y1,x2,y2,x3,y3);
     Points.getPointLocation();                              
                             }//end AskValues()
    
    public void CharacteristicsOfATriangle(){
        
      double sideA = Math.sqrt(((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)));
      double sideB = Math.sqrt(((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2)));
      double sideC = Math.sqrt(((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3)));
                        
      double perimeter = sideA + sideB + sideC;
        
      double pDividedBy2 = (sideA + sideB + sideC) / 2;
      double area = Math.sqrt((pDividedBy2 * (pDividedBy2 - sideA)
              * (pDividedBy2 - sideB) * (pDividedBy2 - sideC)));
      
      double angleA = Math.pow(sideA,2) - Math.pow(sideB,2) - 
             Math.pow(sideC,2) + (2 * sideB * sideC);
      double angleB =Math.pow(sideB,2) - Math.pow(sideC,2) - 
             Math.pow(sideA,2) + (2 * sideC * sideA);
      double angleC = Math.pow(sideC,2) - Math.pow(sideA,2) - 
             Math.pow(sideB,2) + (2 * sideA * sideC);
      
      System.out.println("The distance between Points A and B is: " + 
             Math.round(sideA * 10000.0) / 10000.0 + " units");
      System.out.println("The distance between Points B and C is: " + 
             Math.round(sideB * 10000.0) / 10000.0 + " units");
      System.out.println("The distance between Points C and A is: " + 
             Math.round(sideC * 10000.0) / 10000.0 + " units");
      
      System.out.println("The perimeter of the triangle is: " + 
             Math.round(perimeter * 10000.0) / 10000.0 + " units");
      
      System.out.println("The area of the triangle is: " + 
             Math.round(area * 10000.0) / 10000.0 + " units");
      
      System.out.println("The degree of Angle A is: " + 
              Math.round(Math.pow(angleA,2) * 1.0) / 1.0 + " degrees");
      System.out.println("The degree of Angle B is: " +  
              Math.round(Math.pow(angleB,2) * 1.0) / 1.0 + " degrees");
      System.out.println("The degree of Angle C is: " + 
              Math.round(Math.pow(angleC,2) * 1.0) / 1.0 + " degrees");
      
                                             }//end CharacteristicsOfATriangle()
    public void determineTriangle(){
      
      double sideA = Math.sqrt(((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)));
      double sideB = Math.sqrt(((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2)));
      double sideC = Math.sqrt(((x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3))); 
      
      double angleA = Math.pow(sideA,2) - Math.pow(sideB,2) - 
             Math.pow(sideC,2) + (2 * sideB * sideC);
      double angleB =Math.pow(sideB,2) - Math.pow(sideC,2) - 
             Math.pow(sideA,2) + (2 * sideC * sideA);
      double angleC = Math.pow(sideC,2) - Math.pow(sideA,2) - 
             Math.pow(sideB,2) + (2 * sideA * sideC);
      
      if(sideA == sideB && sideB == sideC && sideC == sideA){
          System.out.println("The triangle is an equalateral triangle");          
                                                            }
      if(angleA > 89 && angleA < 91){
          System.out.println("The triangle is a right triangle");
                                    }
      if(angleB > 89 && angleB < 91){
          System.out.println("The triangle is a right triangle");
                                    }
      if(angleC > 89 && angleC < 91){
          System.out.println("The triangle is a right triangle");
                                    }
     
                                    }//end determineTriange()
           
     public static void main(String[] args) {
     
     TriangleTester Tester = new TriangleTester();
    
     Tester.AskValues();
     Tester.CharacteristicsOfATriangle();
     Tester.determineTriangle();
     
     
        
        
        
        
                
        
                                              }//end main

    
    
                             }//end class

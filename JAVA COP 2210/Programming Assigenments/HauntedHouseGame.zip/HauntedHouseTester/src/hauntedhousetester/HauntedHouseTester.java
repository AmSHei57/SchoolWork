
package hauntedhousetester;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

class HauntedHouseWorkings{

public void ChestLR(){
 JOptionPane.showMessageDialog(null,"You explore the Chest: "
         + "Ghost escapes and scares you to death");
}
public void CandelabraDR(){
 JOptionPane.showMessageDialog(null,"You explore the Candelabra: "
         + "Light up by themselves and see a death shadow");   
}
public void RefrigeratorK(){
 JOptionPane.showMessageDialog(null,"You explore the Refrigerator: "
         + "Open it and find some delicious soul food"); 
}
public void CabinetK(){
 JOptionPane.showMessageDialog(null,"You explore the Cabinet: "
         + "The dishes and glasses start flying at you as soon as you open the door. You get hit in the head and feel yourself start moving towards a light");   
}
public void DustyRecipeBoxP(){
 JOptionPane.showMessageDialog(null,"You explore the Dusty Recipe Box: "
         + "You open it up and a recipe for chocolate devils food cake appears our of no where");   
}
public void BroomP(){
 JOptionPane.showMessageDialog(null,"You explore the Broom: "
         + "Flies up in the air as soon as you touch it"); 
}
public void MirrorB1(){
 JOptionPane.showMessageDialog(null,"You explore the Mirror: "
         + "See a bloody face looking back at you"); 
}
public void ShowerB1(){
 JOptionPane.showMessageDialog(null,"You explore the Shower: "
         + "Room suddenly steams up and you feel fingers touching the back of your neck"); 
}
public void RockingChairBed1(){
 JOptionPane.showMessageDialog(null,"You explore the Rocking Chair: "
         + "Chair starts rocking by itself with no one in it"); 
}
public void WindowBed1(){
 JOptionPane.showMessageDialog(null,"You explore the Window: "
         + "See a child outside on a swing who suddenly disappears"); 
}
public void DollHouseBed2(){
 JOptionPane.showMessageDialog(null,"You explore the Doll House: "
         + "The dolls start dancing on their own"); 
}
public void DresserBed2(){
 JOptionPane.showMessageDialog(null,"You explore the Dresser: "
         + "A ghost flies out of the dresser as soon as you open it and goes right though your body"); 
}
public void JewelryyBoxM(){
 JOptionPane.showMessageDialog(null,"You explore the Jewelry Box: "
         + "You find the cursed Hope Diamond and feel your doom"); 
}
public void IntricateOilLampMB(){
 JOptionPane.showMessageDialog(null,"You explore the Intricate Oil Lamp: "
         + "Rub the lamp and a genie pops out who says he’ll grant you 3 wishes"); 
}
public void ShowerMB(){
 JOptionPane.showMessageDialog(null,"You explore the Shower: "
         + "Suddenly hear singing in the shower, but no one is there"); 
}
public void MirrorB2(){
 JOptionPane.showMessageDialog(null,"You explore the Mirror: "
         + "See a bloody face looking back at you"); 
}
public void ShowerB2(){
 JOptionPane.showMessageDialog(null,"You explore the Shower: "
         + "Room suddenly steams up and you feel fingers touching the back of your neck"); 
}
public void Thanks(){
 JOptionPane.showMessageDialog(null,"Thanks for Playing, Hope you had a SPOOOOKY Time");
}
}
public class HauntedHouseTester {

    
    public static void main(String[] args) {
   
 HauntedHouseWorkings HHW = new HauntedHouseWorkings();
 
 String name = JOptionPane.showInputDialog("Before we begin please state your name");
 JOptionPane.showMessageDialog(null,"Welcome, " + name +", to the Spooky Haunted House Game ");
 JOptionPane.showMessageDialog(null,"Please remember the game only works if you input the numbers given");
 JOptionPane.showMessageDialog(null,"Thank You and Enjoy");
 
 ImageIcon startpic = new ImageIcon("startlocation.jpg");
 JOptionPane.showMessageDialog(null,"You start here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, startpic);
 
 String start = JOptionPane.showInputDialog(name+ ", where do you want to go to start your "
 + "spooky adventure? Living Room(1) ,Dining Room(2) , or Up the Stairs(3)");         
 int s = Integer.parseInt(start); 
if(s==1){    
    JOptionPane.showMessageDialog(null,"Ok " + name +" lets go to the Living Room");
    String lr = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
     + "want to go to the 1st Floor Bathroom(2)?");
    int lR = Integer.parseInt(lr);
   if(lR==1){
        HHW.ChestLR();
        ImageIcon endpic1 = new ImageIcon("endlocation1.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic1);
        HHW.Thanks();  
    }
    else{
        String BR1 = JOptionPane.showInputDialog("Do you want to explore an item in the room?<1(yes) or 2(no)>");
        int bR1 = Integer.parseInt(BR1);
            if(bR1==1){
             String itemBR1 = JOptionPane.showInputDialog("Which item do you want to explore? Mirror(1) or Shower(2)");
             int itembR1=Integer.parseInt(itemBR1);
              if(itembR1==1){
             HHW.MirrorB1();
             ImageIcon endpic2 = new ImageIcon("endlocation2.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic2);
             HHW.Thanks();
              }else{
             HHW.ShowerB1();
             ImageIcon endpic2 = new ImageIcon("endlocation2.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic2);
             HHW.Thanks();
             }
            }else{
            JOptionPane.showMessageDialog(null,"You went home with nothing, sucks for you");
            ImageIcon endpic2 = new ImageIcon("endlocation2.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic2);
            HHW.Thanks();
            }
        }
}else if(s==2){
    JOptionPane.showMessageDialog(null,"Ok " + name +" lets go to the Dining Room");
    String dr = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
     + "want to go to the Kitchen(2)?");
    int DR = Integer.parseInt(dr);
   if(DR==1){
        HHW.CandelabraDR();
        ImageIcon endpic3 = new ImageIcon("endlocation3.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic3);
        HHW.Thanks();
   }
   else{
       String k = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
       + "want to go to the Pantry(2)?");
       int K = Integer.parseInt(k);
        if(K==1){
        String itemk = JOptionPane.showInputDialog("Which item do you want to explore? Cabinet(1) or Refrigerator(2)");  
        int itemK=Integer.parseInt(itemk);
            if (itemK==1){
            HHW.CabinetK();
            ImageIcon endpic4 = new ImageIcon("endlocation4.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic4);
            HHW.Thanks();    
            }
            else{
            HHW.RefrigeratorK();
            ImageIcon endpic4 = new ImageIcon("endlocation4.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic4);
            HHW.Thanks();
            }
          }
        else{
          String p = JOptionPane.showInputDialog("Do you want to explore an item in the room?<1(yes) or 2(no)>");
          int P = Integer.parseInt(p);
            if(P==1){
            String itemp = JOptionPane.showInputDialog("Which item do you want to explore? Broom(1) or Dusty Recipe Box(2)");
             int itemP=Integer.parseInt(itemp);   
             if(itemP==1){
                 HHW.BroomP();
                 ImageIcon endpic5 = new ImageIcon("endlocation5.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic5);
                 HHW.Thanks();
             }
             else{
                 HHW.DustyRecipeBoxP();
                 ImageIcon endpic5 = new ImageIcon("endlocation5.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic5);
                 HHW.Thanks();
             }
            }
            else{
            JOptionPane.showMessageDialog(null,"You went through the spooky house for nothing");
            ImageIcon endpic5 = new ImageIcon("endlocation5.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic5);
            HHW.Thanks();
            }
           }
       
       }
}else{
    JOptionPane.showMessageDialog(null,"Ok" + name +" lets go Up the Stairs");     
    String uts = JOptionPane.showInputDialog(name + " where do you want to go?"
            + " Bedroom1(1), Bedroom2(2), or MasterBedroom(3)");
    int uTS = Integer.parseInt(uts);
     if(uTS==1){
       JOptionPane.showMessageDialog(null,"Ok" + name +" lets go to Bedroom 1"); 
       String b1 = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
       + "want to go to the 2nd Floor Bathroom(2)?");
       int B1 = Integer.parseInt(b1);
         if(B1==1){
          String itemb1 = JOptionPane.showInputDialog("Which item do you want to explore? Window(1) or Rocking Chair(2)");
             int itemB1=Integer.parseInt(itemb1);   
             if(itemB1==1){
                 HHW.WindowBed1();
                 ImageIcon endpic6 = new ImageIcon("endlocation6.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic6);
                 HHW.Thanks();
             }
             else{
                 HHW.RockingChairBed1();
                  ImageIcon endpic6 = new ImageIcon("endlocation6.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic6);
                 HHW.Thanks();
             }   
         }else{
         String fb2 = JOptionPane.showInputDialog("Do you want to explore an item in the room?<1(yes) or 2(no)>");
          int fB2 = Integer.parseInt(fb2); 
           if(fB2==1){
             String itemfb2 = JOptionPane.showInputDialog("Which item do you want to explore? Mirror(1) or Shower(2)");
             int itemFB2=Integer.parseInt(itemfb2); 
              if(itemFB2==1){
                  HHW.MirrorB2();
                  ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
                  HHW.Thanks();
              }else{
                  HHW.ShowerB2();
                  ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
                  HHW.Thanks();
              }
         }else{
            JOptionPane.showMessageDialog(null,"You can take the towels if you want");
            ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
            HHW.Thanks();   
           }
          }
     }else if(uTS==2){
        JOptionPane.showMessageDialog(null,"Ok" + name +" lets go to Bedroom 2"); 
        String b2 = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
        + "want to go to the 2nd Floor Bathroom(2)?");
        int B2 = Integer.parseInt(b2);
         if(B2==1){
          String itemb2 = JOptionPane.showInputDialog("Which item do you want to explore? Doll House(1) or Dresser(2)");
             int itemB2=Integer.parseInt(itemb2);   
             if(itemB2==1){
                 HHW.DollHouseBed2();
                ImageIcon endpic8 = new ImageIcon("endlocation8.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic8);
                 HHW.Thanks();
             }
             else{
                 HHW.DresserBed2();
                 ImageIcon endpic8 = new ImageIcon("endlocation8.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic8);
                 HHW.Thanks();
             }    
            }else{
            String fb2 = JOptionPane.showInputDialog("Do you want to explore an item in the room?<1(yes) or 2(no)>");
          int fB2 = Integer.parseInt(fb2); 
           if(fB2==1){
             String itemfb2 = JOptionPane.showInputDialog("Which item do you want to explore? Mirror(1) or Shower(2)");
             int itemFB2=Integer.parseInt(itemfb2); 
              if(itemFB2==1){
                  HHW.MirrorB2();
                  ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
                  HHW.Thanks();
              }else{
                  HHW.ShowerB2();
                  ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
                  HHW.Thanks();
              }
         }else{
            JOptionPane.showMessageDialog(null,"You can take the towels if you want");
            ImageIcon endpic7 = new ImageIcon("endlocation7.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic7);
            HHW.Thanks();  
              }
               }   
     }else{
      JOptionPane.showMessageDialog(null,"Ok" + name +" lets go to the Master Bedroom");      
       String mbed = JOptionPane.showInputDialog("Do you want to explore an item(1) or do you "
        + "want to go to the Master Bathroom(2)?");
        int mBed = Integer.parseInt(mbed);
            if(mBed==1){
            HHW.JewelryyBoxM();
           ImageIcon endpic9 = new ImageIcon("endlocation9.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic9);
            HHW.Thanks();
            }
            else{
            String mbr = JOptionPane.showInputDialog("Do you want to explore an item in the room?<1(yes) or 2(no)>");
            int mBR = Integer.parseInt(mbr);     
              if(mBR==1){
              String itemmbr = JOptionPane.showInputDialog("Which item do you want to explore? Shower(1) or Intricate Oil Lamp(2)");
             int itemMBR=Integer.parseInt(itemmbr); 
              if(itemMBR==1){
                  HHW.ShowerMB();
                  ImageIcon endpic10 = new ImageIcon("endlocation10.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic10);
                  HHW.Thanks();
               }else{
                  HHW.IntricateOilLampMB();
                   ImageIcon endpic10 = new ImageIcon("endlocation10.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic10);
                  HHW.Thanks();
              }    
              }
              else{
              JOptionPane.showMessageDialog(null,"You can take the soap if you want, you're not getting anything else");
               ImageIcon endpic10 = new ImageIcon("endlocation10.jpg");
 JOptionPane.showMessageDialog(null,"You ended here ","Haunted House Game",JOptionPane.INFORMATION_MESSAGE, endpic10);
              HHW.Thanks();       
              }
            
            }
     }

}
}
}